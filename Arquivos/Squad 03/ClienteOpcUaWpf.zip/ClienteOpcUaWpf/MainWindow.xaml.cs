﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Opc.Ua;
using Opc.Ua.Configuration;
using Opc.Ua.Client;

namespace OPCuaArduino.Client
{
    public partial class MainWindow : Window
    {
        private bool _isConnected = false;
        private Session _session;
        private ApplicationConfiguration _config;
        private CancellationTokenSource _monitoringToken;
        
        // Nodes OPC UA (ajuste conforme seu servidor)
        private const string SERVER_URL = "opc.tcp://localhost:4840";
        private string NodeAlturaPlanta = "ns=2;s=AlturaPlanta";
        private string NodeUmidadeSolo = "ns=2;s=UmidadeSolo";
        private string NodeLuz = "ns=2;s=Luz";
        private string NodeRega = "ns=2;s=Rega";
        private string NodeVentilador = "ns=2;s=Ventilador";
        private string NodeServoMotor = "ns=2;s=ServoMotor";
        private string NodeMotorL298N = "ns=2;s=MotorL298N";

        public MainWindow()
        {
            InitializeComponent();
            InitializeOpcUaConfig();
        }

        private void InitializeOpcUaConfig()
        {
            try
            {
                _config = new ApplicationConfiguration()
                {
                    ApplicationName = "OPC UA Arduino Client",
                    ApplicationType = ApplicationType.Client,
                    ApplicationUri = Utils.Format(@"urn:{0}:OPCUAArduinoClient", System.Net.Dns.GetHostName()),
                    SecurityConfiguration = new SecurityConfiguration
                    {
                        ApplicationCertificate = new CertificateIdentifier { StoreType = @"Directory", StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\MachineDefault" },
                        TrustedPeerCertificates = new CertificateTrustList { StoreType = @"Directory", StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\UA Applications" },
                        TrustedIssuerCertificates = new CertificateTrustList { StoreType = @"Directory", StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\UA Certificate Authorities" },
                        RejectedCertificateStore = new CertificateTrustList { StoreType = @"Directory", StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\RejectedCertificates" },
                        AutoAcceptUntrustedCertificates = true
                    },
                    TransportConfigurations = new TransportConfigurationCollection(),
                    TransportQuotas = new TransportQuotas { OperationTimeout = 15000 },
                    ClientConfiguration = new ClientConfiguration { DefaultSessionTimeout = 60000 },
                    CertificateValidator = new CertificateValidator()
                };

                _config.CertificateValidator.CertificateValidation += (validator, e) =>
                {
                    e.Accept = true;
                };

                _config.Validate(ApplicationType.Client).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro na configuração OPC UA: {ex.Message}");
            }
        }

        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_isConnected)
            {
                try
                {
                    StatusLabel.Text = "Conectando...";
                    ConnectButton.IsEnabled = false;

                    // Conecta ao servidor OPC UA
                    await ConnectToOpcUaServer();
                    
                    _isConnected = true;
                    StatusLabel.Text = "Conectado";
                    StatusLabel.Foreground = System.Windows.Media.Brushes.Green;
                    ConnectButton.Content = "Desconectar";

                    // Inicia monitoramento dos dados
                    _monitoringToken = new CancellationTokenSource();
                    _ = MonitorData(_monitoringToken.Token);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro na conexão: {ex.Message}");
                    StatusLabel.Text = "Erro na conexão";
                    ConnectButton.IsEnabled = true;
                }
            }
            else
            {
                // Desconecta
                _isConnected = false;
                _monitoringToken?.Cancel();
                
                if (_session != null)
                {
                    _session.Close();
                    _session.Dispose();
                    _session = null;
                }
                
                StatusLabel.Text = "Desconectado";
                StatusLabel.Foreground = System.Windows.Media.Brushes.Red;
                ConnectButton.Content = "Conectar";
                
                // Reseta valores
                ResetDisplayValues();
            }
            ConnectButton.IsEnabled = true;
        }

        private void ResetDisplayValues()
        {
            TextBlockAltura.Text = "-- cm";
            TextBlockUmidade.Text = "-- %";
            TextBlockLuz.Text = "Desconhecido";
            TextBlockRega.Text = "Parada";
            TextBlockVentilador.Text = "0";
            TextBlockServo.Text = "Desconhecido";
            TextBlockMotorL298N.Text = "Desconhecido";
            LuzCheckBox.IsChecked = false;
        }

        private async Task ConnectToOpcUaServer()
        {
            try
            {
                // CORREÇÃO: Passando a ApplicationConfiguration como primeiro parâmetro
                var endpointDescription = CoreClientUtils.SelectEndpoint(_config, SERVER_URL, useSecurity: false);
                var endpointConfiguration = EndpointConfiguration.Create(_config);
                var endpoint = new ConfiguredEndpoint(null, endpointDescription, endpointConfiguration);

                _session = await Session.Create(
                    _config,
                    endpoint,
                    false,
                    false,
                    _config.ApplicationName,
                    60000,
                    null,
                    null);

                if (_session != null && _session.Connected)
                {
                    StatusLabel.Text = "Conectado";
                }
                else
                {
                    throw new Exception("Falha ao estabelecer conexão com o servidor");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao conectar com servidor OPC UA: {ex.Message}");
            }
        }

        private async Task MonitorData(CancellationToken token)
        {
            while (!token.IsCancellationRequested && _session != null && _session.Connected)
            {
                try
                {
                    // Lê os valores atuais dos nodes
                    var readValues = await ReadNodeValues();
                    
                    await Dispatcher.InvokeAsync(() =>
                    {
                        // Atualiza a interface com os valores reais
                        TextBlockAltura.Text = $"{readValues.altura:F2} cm";
                        TextBlockUmidade.Text = $"{readValues.umidade:F1} %";
                        TextBlockLuz.Text = readValues.luz ? "Ligada" : "Desligada";
                        TextBlockRega.Text = readValues.rega ? "Regando..." : "Parada";
                        TextBlockVentilador.Text = readValues.ventilador.ToString();
                        TextBlockServo.Text = readValues.servo ? "Ligado" : "Desligado";
                        TextBlockMotorL298N.Text = readValues.motorL298N ? "Ligado" : "Desligado";

                        // Atualiza o estado dos controles
                        LuzCheckBox.IsChecked = readValues.luz;
                        ServoButton.Content = readValues.servo ? "Desligar Servo" : "Ligar Servo";
                        MotorL298NButton.Content = readValues.motorL298N ? "Desligar Motor L298N" : "Ligar Motor L298N";
                    });

                    await Task.Delay(1000, token);
                }
                catch (Exception ex)
                {
                    await Dispatcher.InvokeAsync(() => 
                    {
                        StatusLabel.Text = "Erro na leitura";
                    });
                    await Task.Delay(5000, token);
                }
            }
        }

        private async Task<(double altura, double umidade, bool luz, bool rega, int ventilador, bool servo, bool motorL298N)> ReadNodeValues()
        {
            if (_session == null || !_session.Connected)
                return (0, 0, false, false, 0, false, false);

            try
            {
                // Cria lista de nodes para ler
                var nodesToRead = new ReadValueIdCollection
                {
                    new ReadValueId { NodeId = new NodeId(NodeAlturaPlanta), AttributeId = Attributes.Value },
                    new ReadValueId { NodeId = new NodeId(NodeUmidadeSolo), AttributeId = Attributes.Value },
                    new ReadValueId { NodeId = new NodeId(NodeLuz), AttributeId = Attributes.Value },
                    new ReadValueId { NodeId = new NodeId(NodeRega), AttributeId = Attributes.Value },
                    new ReadValueId { NodeId = new NodeId(NodeVentilador), AttributeId = Attributes.Value },
                    new ReadValueId { NodeId = new NodeId(NodeServoMotor), AttributeId = Attributes.Value },
                    new ReadValueId { NodeId = new NodeId(NodeMotorL298N), AttributeId = Attributes.Value }
                };

                // Lê os valores
                _session.Read(
                    null,
                    0,
                    TimestampsToReturn.Both,
                    nodesToRead,
                    out DataValueCollection results,
                    out DiagnosticInfoCollection diagnosticInfos);

                // Processa os resultados
                double altura = results[0].Value != null ? Convert.ToDouble(results[0].Value) : 0;
                double umidade = results[1].Value != null ? Convert.ToDouble(results[1].Value) : 0;
                bool luz = results[2].Value != null ? Convert.ToBoolean(results[2].Value) : false;
                bool rega = results[3].Value != null ? Convert.ToBoolean(results[3].Value) : false;
                int ventilador = results[4].Value != null ? Convert.ToInt32(results[4].Value) : 0;
                bool servo = results[5].Value != null ? Convert.ToBoolean(results[5].Value) : false;
                bool motorL298N = results[6].Value != null ? Convert.ToBoolean(results[6].Value) : false;

                return (altura, umidade, luz, rega, ventilador, servo, motorL298N);
            }
            catch (Exception ex)
            {
                // Retorna valores padrão em caso de erro
                return (25.5, 65.0, false, false, 0, false, false);
            }
        }

        private async Task WriteNodeValue(string nodeId, object value)
        {
            if (_session == null || !_session.Connected || !_isConnected)
            {
                MessageBox.Show("Conecte primeiro ao servidor.");
                return;
            }

            try
            {
                var writeValue = new WriteValue
                {
                    NodeId = new NodeId(nodeId),
                    AttributeId = Attributes.Value,
                    Value = new DataValue(new Variant(value))
                };

                var writeValues = new WriteValueCollection { writeValue };

                _session.Write(
                    null,
                    writeValues,
                    out StatusCodeCollection results,
                    out DiagnosticInfoCollection diagnosticInfos);

                if (results != null && results.Count > 0 && StatusCode.IsGood(results[0]))
                {
                    // Sucesso
                    Console.WriteLine($"Comando enviado: {nodeId} = {value}");
                }
                else
                {
                    MessageBox.Show($"Erro ao enviar comando para {nodeId}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao enviar comando: {ex.Message}");
            }
        }

        private void LuzCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            if (!_isConnected)
            {
                MessageBox.Show("Conecte primeiro para usar os controles.");
                LuzCheckBox.IsChecked = !LuzCheckBox.IsChecked;
                return;
            }

            bool luzState = LuzCheckBox.IsChecked == true;
            _ = WriteNodeValue(NodeLuz, luzState);
        }

        private async void RegaButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_isConnected)
            {
                MessageBox.Show("Conecte primeiro para usar os controles.");
                return;
            }

            // Liga a rega
            await WriteNodeValue(NodeRega, true);
            await Task.Delay(3000);
            // Desliga a rega após 3 segundos
            await WriteNodeValue(NodeRega, false);
        }

        private void VentiladorButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_isConnected)
            {
                MessageBox.Show("Conecte primeiro para usar os controles.");
                return;
            }

            if (int.TryParse(FanSpeedTextBox.Text, out int velocidade))
            {
                if (velocidade < 0) velocidade = 0;
                if (velocidade > 100) velocidade = 100;
                
                _ = WriteNodeValue(NodeVentilador, velocidade);
            }
            else
            {
                MessageBox.Show("Digite um valor numérico para a velocidade (0 a 100).");
            }
        }

        private void ServoButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_isConnected)
            {
                MessageBox.Show("Conecte primeiro para usar os controles.");
                return;
            }

            // Alterna o estado do servo motor
            bool novoEstado = TextBlockServo.Text != "Ligado";
            _ = WriteNodeValue(NodeServoMotor, novoEstado);
        }

        private void MotorL298NButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_isConnected)
            {
                MessageBox.Show("Conecte primeiro para usar os controles.");
                return;
            }

            // Alterna o estado do motor L298N
            bool novoEstado = TextBlockMotorL298N.Text != "Ligado";
            _ = WriteNodeValue(NodeMotorL298N, novoEstado);
        }

        protected override void OnClosed(EventArgs e)
        {
            _monitoringToken?.Cancel();
            _session?.Close();
            _session?.Dispose();
            base.OnClosed(e);
        }
    }
}