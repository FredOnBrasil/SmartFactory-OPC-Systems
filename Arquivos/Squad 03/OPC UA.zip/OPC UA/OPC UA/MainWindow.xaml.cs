﻿using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Threading;

namespace WpfSimpleSimulator
{
    // A classe agora implementa a interface INotifyPropertyChanged
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        // Implementação padrão da interface
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // ----- PROPRIEDADES CONVERTIDAS PARA O FORMATO MANUAL -----
        private double _distancia = 1000.0;
        public double Distancia
        {
            get => _distancia;
            set { if (_distancia != value) { _distancia = value; OnPropertyChanged(); } }
        }

        private double _umidade = 55.0;
        public double Umidade
        {
            get => _umidade;
            set { if (_umidade != value) { _umidade = value; OnPropertyChanged(); } }
        }

        private double _angulacao = 15.0;
        public double Angulacao
        {
            get => _angulacao;
            set { if (_angulacao != value) { _angulacao = value; OnPropertyChanged(); } }
        }

        private double _velocidade = 80.0;
        public double Velocidade
        {
            get => _velocidade;
            set { if (_velocidade != value) { _velocidade = value; OnPropertyChanged(); } }
        }

        private string _statusSimulacao = "Parado";
        public string StatusSimulacao
        {
            get => _statusSimulacao;
            set { if (_statusSimulacao != value) { _statusSimulacao = value; OnPropertyChanged(); } }
        }
        
        // Propriedade que contém a lista para a ComboBox (apenas uma declaração)
        public List<string> GrandezasDisponiveis { get; }
        
        private string _selectedGrandezda;
        public string SelectedGrandezda
        {
            get => _selectedGrandezda;
            set
            {
                if (_selectedGrandezda != value)
                {
                    _selectedGrandezda = value;
                    OnPropertyChanged();
                }
            }
        }

        // O "motor" da nossa simulação
        private readonly DispatcherTimer _timer;
        private readonly Random _random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            
            // Preenche a lista de opções para a ComboBox (apenas uma vez)
            GrandezasDisponiveis = new List<string>
            {
                "Distância", "Umidade", "Angulação", "Velocidade"
            };

            // Define o item inicial que será selecionado
            SelectedGrandezda = GrandezasDisponiveis[0];
            
            // Configura o timer
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(500);
            _timer.Tick += OnTimerTick;
        }

        private void OnTimerTick(object? sender, EventArgs e)
        {
            Distancia -= _random.NextDouble() * 5;
            if (Distancia < 0) Distancia = 1000.0;

            Umidade += (_random.NextDouble() - 0.5) * 0.5;
            Umidade = Math.Clamp(Umidade, 40, 70);

            Angulacao += (_random.NextDouble() - 0.5) * 1.5;
            Angulacao = Math.Clamp(Angulacao, -20, 20);

            Velocidade += (_random.NextDouble() - 0.5) * 2;
            Velocidade = Math.Clamp(Velocidade, 60, 110);
        }

        [RelayCommand]
        private void IniciarSimulacao()
        {
            _timer.Start();
            StatusSimulacao = "Rodando...";
        }

        [RelayCommand]
        private void PararSimulacao()
        {
            _timer.Stop();
            StatusSimulacao = "Parado";
        }
    }
}