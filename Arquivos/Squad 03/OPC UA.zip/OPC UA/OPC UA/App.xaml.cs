﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace OPC_UA;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}