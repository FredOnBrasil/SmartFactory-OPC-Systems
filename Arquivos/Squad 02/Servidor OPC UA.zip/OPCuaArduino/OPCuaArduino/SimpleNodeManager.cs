﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO.Ports;
using System.Threading.Tasks;
using Opc.Ua;
using Opc.Ua.Server;

namespace OPCuaArduino
{
    public class SimpleNodeManager : CustomNodeManager2
    {
        private SerialPort? _serialPort;
        private System.Timers.Timer? _reconnectTimer;

        // Variáveis OPC UA para os dados dos sensores (Leitura)
        private BaseDataVariableState<double>? _alturaPlantaVariable;
        private BaseDataVariableState<int>? _umidadeSoloVariable;
        private BaseDataVariableState<bool>? _luzLigadaVariable;
        private BaseDataVariableState<bool>? _regandoVariable;
        private BaseDataVariableState<int>? _velocidadeVentiladorVariable;

        // Variáveis OPC UA para os comandos (Escrita)
        private BaseDataVariableState<bool>? _comandoLuzVariable;
        private BaseDataVariableState<int>? _comandoVentiladorVariable;
        private BaseDataVariableState<bool>? _comandoRegaVariable;

        public SimpleNodeManager(IServerInternal server, ApplicationConfiguration configuration)
            : base(server, configuration, "urn:OPCuaArduino:NodeManager")
        {
            SystemContext.NodeIdFactory = this;
        }

        public override void CreateAddressSpace(IDictionary<NodeId, IList<IReference>> externalReferences)
        {
            lock (Lock)
            {
                base.CreateAddressSpace(externalReferences);

                // Cria a pasta principal para organizar as variáveis
                var folder = new FolderState(null)
                {
                    NodeId = new NodeId("ArduinoPlanta", NamespaceIndex),
                    BrowseName = new QualifiedName("ArduinoPlanta", NamespaceIndex),
                    DisplayName = new LocalizedText("Estufa Arduino"),
                    TypeDefinitionId = ObjectTypeIds.FolderType
                };
                folder.AddReference(ReferenceTypeIds.Organizes, true, ObjectIds.ObjectsFolder);
                AddPredefinedNode(SystemContext, folder);

                // Variáveis de Leitura (sensores)
                _alturaPlantaVariable = CreateVariable<double>(
                    folder, 
                    "AlturaPlanta", 
                    "Altura da Planta (cm)", 
                    0.0, 
                    DataTypeIds.Double, 
                    AccessLevels.CurrentRead | AccessLevels.HistoryRead
                );
                
                _umidadeSoloVariable = CreateVariable<int>(
                    folder, 
                    "UmidadeSolo", 
                    "Umidade do Solo (%)", 
                    0, 
                    DataTypeIds.Int32, 
                    AccessLevels.CurrentRead | AccessLevels.HistoryRead
                );
                
                _luzLigadaVariable = CreateVariable<bool>(
                    folder, 
                    "StatusLuz", 
                    "Status da Luz", 
                    false, 
                    DataTypeIds.Boolean, 
                    AccessLevels.CurrentRead | AccessLevels.HistoryRead
                );
                
                _regandoVariable = CreateVariable<bool>(
                    folder, 
                    "StatusRega", 
                    "Status da Rega", 
                    false, 
                    DataTypeIds.Boolean, 
                    AccessLevels.CurrentRead | AccessLevels.HistoryRead
                );
                
                _velocidadeVentiladorVariable = CreateVariable<int>(
                    folder, 
                    "StatusVentilador", 
                    "Velocidade do Ventilador", 
                    0, 
                    DataTypeIds.Int32, 
                    AccessLevels.CurrentRead | AccessLevels.HistoryRead
                );

                // Variáveis de Escrita (comandos)
                _comandoLuzVariable = CreateVariable<bool>(
                    folder, 
                    "ComandoLuz", 
                    "Comando: Ligar/Desligar Luz", 
                    false, 
                    DataTypeIds.Boolean, 
                    AccessLevels.CurrentRead | AccessLevels.CurrentWrite
                );
                
                _comandoVentiladorVariable = CreateVariable<int>(
                    folder, 
                    "ComandoVentilador", 
                    "Comando: Velocidade Ventilador (0-255)", 
                    0, 
                    DataTypeIds.Int32, 
                    AccessLevels.CurrentRead | AccessLevels.CurrentWrite
                );
                
                _comandoRegaVariable = CreateVariable<bool>(
                    folder, 
                    "ComandoRega", 
                    "Comando: Acionar Rega (escrever 'true')", 
                    false, 
                    DataTypeIds.Boolean, 
                    AccessLevels.CurrentRead | AccessLevels.CurrentWrite
                );

                // Associa os métodos de escrita
                _comandoLuzVariable.OnWriteValue = OnLuzWrite;
                _comandoVentiladorVariable.OnWriteValue = OnVentiladorWrite;
                _comandoRegaVariable.OnWriteValue = OnRegaWrite;

                Console.WriteLine("✅ Espaço de endereços OPC UA criado com sucesso!");
                InitializeSerialPort();
            }
        }

        #region Comunicação Serial com Arduino

        private void InitializeSerialPort()
        {
            try
            {
                string portName = "COM7"; 
                _serialPort = new SerialPort(portName, 9600)
                {
                    ReadTimeout = 1000,
                    WriteTimeout = 1000,
                    DtrEnable = true,
                    RtsEnable = true
                };
                _serialPort.DataReceived += SerialPort_DataReceived;
                _serialPort.Open();
                Console.WriteLine($"✅ Porta serial {portName} aberta com sucesso.");
                
                // Para qualquer timer de reconexão anterior
                if(_reconnectTimer != null)
                {
                    _reconnectTimer.Stop();
                    _reconnectTimer.Dispose();
                    _reconnectTimer = null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ ERRO ao abrir porta serial: {ex.Message}. Tentando reconectar em 5 segundos...");
                ScheduleReconnect();
            }
        }

        private void ScheduleReconnect()
        {
            _reconnectTimer = new System.Timers.Timer(5000);
            _reconnectTimer.Elapsed += (sender, e) => 
            {
                Console.WriteLine("🔄 Tentando reconectar à porta serial...");
                InitializeSerialPort();
            };
            _reconnectTimer.AutoReset = false; 
            _reconnectTimer.Start();
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (_serialPort == null || !_serialPort.IsOpen) return;
            
            try
            {
                string line = _serialPort.ReadLine().Trim();
                Console.WriteLine($"📨 Dados recebidos do Arduino: {line}");

                // Processa os dados no formato: "A:12.5;U:65;L:1;R:0;V:128"
                string[] parts = line.Split(';');
                foreach (var part in parts)
                {
                    if (string.IsNullOrWhiteSpace(part)) continue;
                    
                    string[] pair = part.Split(':');
                    if (pair.Length != 2) continue;

                    string key = pair[0].Trim();
                    string value = pair[1].Trim();

                    ProcessSensorData(key, value);
                }
            }
            catch (TimeoutException)
            {
                // Timeout é normal, ignora
            }
            catch (Exception ex)
            {
                Console.WriteLine($"⚠ ERRO ao processar dados seriais: {ex.Message}");
            }
        }

        private void ProcessSensorData(string key, string value)
        {
            try
            {
                switch (key)
                {
                    case "A": // Altura
                        if (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out double altura))
                        {
                            UpdateVariable(_alturaPlantaVariable, Math.Round(altura, 2));
                            Console.WriteLine($"🌱 Altura da planta atualizada: {altura} cm");
                        }
                        break;
                        
                    case "U": // Umidade
                        if (int.TryParse(value, out int umidade))
                        {
                            UpdateVariable(_umidadeSoloVariable, umidade);
                            Console.WriteLine($"💧 Umidade do solo atualizada: {umidade}%");
                        }
                        break;
                        
                    case "L": // Luz
                        bool luzStatus = value == "1";
                        UpdateVariable(_luzLigadaVariable, luzStatus);
                        Console.WriteLine($"💡 Status da luz atualizado: {(luzStatus ? "LIGADA" : "DESLIGADA")}");
                        break;
                        
                    case "R": // Rega
                        bool regaStatus = value == "1";
                        UpdateVariable(_regandoVariable, regaStatus);
                        Console.WriteLine($"🚰 Status da rega atualizado: {(regaStatus ? "REGANDO" : "PARADA")}");
                        break;
                        
                    case "V": // Ventilador
                        if (int.TryParse(value, out int velocidade))
                        {
                            UpdateVariable(_velocidadeVentiladorVariable, velocidade);
                            Console.WriteLine($"🌀 Velocidade do ventilador atualizada: {velocidade}/255");
                        }
                        break;
                        
                    default:
                        Console.WriteLine($"❓ Chave desconhecida recebida: {key}");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao processar dado '{key}:{value}': {ex.Message}");
            }
        }

        #endregion

        #region Handlers de Escrita (Comandos para o Arduino)

        private ServiceResult OnLuzWrite(ISystemContext context, NodeState node, NumericRange indexRange, 
            QualifiedName dataEncoding, ref object value, ref StatusCode statusCode, ref DateTime timestamp)
        {
            try
            {
                if (_serialPort?.IsOpen == true)
                {
                    bool ligar = (bool)value;
                    string command = ligar ? "L1\n" : "L0\n"; 
                    _serialPort.Write(command);
                    Console.WriteLine($"💻 Enviando comando para o Arduino: {command.Trim()}");
                    
                    // Atualiza a variável de status para refletir o comando
                    UpdateVariable(_luzLigadaVariable, ligar);
                    
                    return ServiceResult.Good;
                }
                return new ServiceResult(StatusCodes.BadCommunicationError, "Porta serial não está disponível.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao enviar comando de luz: {ex.Message}");
                return new ServiceResult(StatusCodes.BadInternalError, ex.Message);
            }
        }

        private ServiceResult OnVentiladorWrite(ISystemContext context, NodeState node, NumericRange indexRange, 
            QualifiedName dataEncoding, ref object value, ref StatusCode statusCode, ref DateTime timestamp)
        {
            try
            {
                if (_serialPort?.IsOpen == true)
                {
                    int velocidade = Convert.ToInt32(value);
                    velocidade = Math.Max(0, Math.Min(255, velocidade)); // Limita entre 0-255
                    
                    string command = $"F{velocidade}\n";
                    _serialPort.Write(command);
                    Console.WriteLine($"💻 Enviando comando para o Arduino: {command.Trim()}");
                    
                    // Atualiza a variável de status
                    UpdateVariable(_velocidadeVentiladorVariable, velocidade);
                    
                    return ServiceResult.Good;
                }
                return new ServiceResult(StatusCodes.BadCommunicationError, "Porta serial não está disponível.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao enviar comando do ventilador: {ex.Message}");
                return new ServiceResult(StatusCodes.BadInternalError, ex.Message);
            }
        }

        private ServiceResult OnRegaWrite(ISystemContext context, NodeState node, NumericRange indexRange, 
            QualifiedName dataEncoding, ref object value, ref StatusCode statusCode, ref DateTime timestamp)
        {
            try
            {
                bool comandoRega = (bool)value;
                
                if (comandoRega && _serialPort?.IsOpen == true)
                {
                    string command = "W\n";
                    _serialPort.Write(command);
                    Console.WriteLine($"💻 Enviando comando para o Arduino: {command.Trim()}");

                    // Reseta automaticamente o comando para false após enviar
                    // Isso permite que o cliente escreva 'true' novamente para acionar nova rega
                    Task.Delay(100).ContinueWith(t => 
                    {
                        try
                        {
                            UpdateVariable(_comandoRegaVariable, false);
                            Console.WriteLine("🔄 Comando de rega resetado para false");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"❌ Erro ao resetar comando de rega: {ex.Message}");
                        }
                    });

                    return ServiceResult.Good;
                }
                
                // Se for false, apenas aceita sem enviar comando
                return ServiceResult.Good;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao enviar comando de rega: {ex.Message}");
                return new ServiceResult(StatusCodes.BadInternalError, ex.Message);
            }
        }

        #endregion

        #region Métodos Auxiliares

        private BaseDataVariableState<T> CreateVariable<T>(NodeState parent, string symbolicName, 
            string displayName, T initialValue, NodeId dataType, byte accessLevel)
        {
            var variable = new BaseDataVariableState<T>(parent)
            {
                SymbolicName = symbolicName,
                ReferenceTypeId = ReferenceTypes.HasComponent,
                NodeId = new NodeId(symbolicName, NamespaceIndex),
                BrowseName = new QualifiedName(symbolicName, NamespaceIndex),
                DisplayName = new LocalizedText("pt-BR", displayName),
                Value = initialValue,
                DataType = dataType,
                AccessLevel = accessLevel,
                UserAccessLevel = accessLevel,
                StatusCode = StatusCodes.Good,
                Timestamp = DateTime.UtcNow,
                WriteMask = AttributeWriteMask.DisplayName | AttributeWriteMask.Description,
                UserWriteMask = AttributeWriteMask.DisplayName | AttributeWriteMask.Description
            };

            parent.AddChild(variable);
            AddPredefinedNode(SystemContext, variable);
            
            Console.WriteLine($"✅ Variável OPC UA criada: {symbolicName}");
            return variable;
        }

        private void UpdateVariable<T>(BaseDataVariableState<T>? variable, T value)
        {
            if (variable == null) return;
            
            lock (Lock)
            {
                variable.Value = value;
                variable.Timestamp = DateTime.UtcNow;
                variable.StatusCode = StatusCodes.Good;
                variable.ClearChangeMasks(SystemContext, false);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _reconnectTimer?.Stop();
                _reconnectTimer?.Dispose();
                
                if (_serialPort != null)
                {
                    _serialPort.DataReceived -= SerialPort_DataReceived;
                    if (_serialPort.IsOpen)
                    {
                        _serialPort.Close();
                    }
                    _serialPort.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #endregion
    }
}