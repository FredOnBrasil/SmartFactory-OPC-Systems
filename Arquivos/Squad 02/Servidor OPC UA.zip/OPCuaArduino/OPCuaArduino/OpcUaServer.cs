﻿using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using Opc.Ua;
using Opc.Ua.Configuration;
using Opc.Ua.Server;

namespace OPCuaArduino
{
    public class OpcUaServer
    {
        private ApplicationInstance? _application;
        private StandardServer? _server;

        public async Task StartAsync()
        {
            try
            {
                // Garante que as pastas de certificado existam
                Directory.CreateDirectory("CertificateStores/UA_MachineDefault");
                Directory.CreateDirectory("CertificateStores/UA_Trust");
                Directory.CreateDirectory("CertificateStores/UA_Issuer");
                Directory.CreateDirectory("CertificateStores/RejectedCertificates");

                var config = new ApplicationConfiguration()
                {
                    ApplicationName = "OPCuaArduinoServer",
                    ApplicationUri = $"urn:{System.Net.Dns.GetHostName()}:OPCuaArduinoServer",
                    ApplicationType = ApplicationType.Server,

                    SecurityConfiguration = new SecurityConfiguration
                    {
                        ApplicationCertificate = new CertificateIdentifier
                        {
                            StoreType = "Directory",
                            StorePath = "CertificateStores/UA_MachineDefault",
                            SubjectName = $"CN=OPCuaArduinoServer, DC={System.Net.Dns.GetHostName()}"
                        },
                        TrustedPeerCertificates = new CertificateTrustList
                        {
                            StoreType = "Directory",
                            StorePath = "CertificateStores/UA_Trust"
                        },
                        TrustedIssuerCertificates = new CertificateTrustList
                        {
                            StoreType = "Directory",
                            StorePath = "CertificateStores/UA_Issuer"
                        },
                        RejectedCertificateStore = new CertificateTrustList
                        {
                            StoreType = "Directory",
                            StorePath = "CertificateStores/RejectedCertificates"
                        },
                        AutoAcceptUntrustedCertificates = true
                    },

                    ServerConfiguration = new ServerConfiguration
                    {
                        BaseAddresses = { "opc.tcp://10.94.93.25:4840/OPCuaArduino" },
                        SecurityPolicies = {
                            new ServerSecurityPolicy {
                                SecurityMode = MessageSecurityMode.None,
                                SecurityPolicyUri = SecurityPolicies.None
                            }
                        }
                    },

                    TransportQuotas = new TransportQuotas { OperationTimeout = 15000 },
                    TraceConfiguration = new TraceConfiguration()
                };

                Console.WriteLine("Validating configuration...");
                await config.ValidateAsync(ApplicationType.Server);

                _application = new ApplicationInstance
                {
                    ApplicationName = "OPCuaArduinoServer",
                    ApplicationType = ApplicationType.Server,
                    ApplicationConfiguration = config
                };

                _server = new SimpleOpcServer();

                Console.WriteLine("Starting server...");
                await _application.StartAsync(_server);

                Console.WriteLine("Servidor OPC UA iniciado em opc.tcp://10.94.93.25:4840/OPCuaArduino");
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERRO ao iniciar servidor: " + ex.ToString());
                throw;
            }
        }

        public async Task StopAsync()
        {
            if (_server != null)
            {
                await Task.Run(() => _server.Stop());
                Console.WriteLine("Servidor OPC UA parado.");
            }
        }
    }

    public class SimpleOpcServer : StandardServer
    {
        protected override MasterNodeManager CreateMasterNodeManager(
            IServerInternal server, ApplicationConfiguration configuration)
        {
            var nodeManagers = new List<INodeManager>
            {
                new SimpleNodeManager(server, configuration)
            };
            return new MasterNodeManager(server, configuration, null, nodeManagers.ToArray());
        }

        protected override void OnServerStarting(ApplicationConfiguration configuration)
        {
            base.OnServerStarting(configuration);
            Console.WriteLine("SimpleOpcServer inicializando...");
        }

        protected override void OnServerStarted(IServerInternal server)
        {
            base.OnServerStarted(server);
            Console.WriteLine("SimpleOpcServer iniciado com sucesso!");
        }

        protected override void OnServerStopping()
        {
            base.OnServerStopping();
            Console.WriteLine("SimpleOpcServer parando...");
        }
    }
}