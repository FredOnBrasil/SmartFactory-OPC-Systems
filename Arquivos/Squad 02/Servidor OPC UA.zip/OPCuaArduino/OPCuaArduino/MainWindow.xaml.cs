﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Threading.Tasks;

namespace OPCuaArduino
{
    public partial class MainWindow : Window
    {
        private readonly OpcUaServer _server = new OpcUaServer();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void btnStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                btnStart.IsEnabled = false;
                txtStatus.Text = "Status: Iniciando...";
                await _server.StartAsync();
                txtStatus.Text = "Status: Servidor Iniciado (opc.tcp://localhost:4840/OPCuaArduino)";
                btnStop.IsEnabled = true;
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Status: Erro ao iniciar servidor";
                MessageBox.Show(ex.ToString(), "Erro ao iniciar servidor", MessageBoxButton.OK, MessageBoxImage.Error);
                btnStart.IsEnabled = true;
            }
        }

        private async void btnStop_Click(object sender, RoutedEventArgs e)
        {
            btnStop.IsEnabled = false;
            txtStatus.Text = "Status: Parando servidor...";
            await _server.StopAsync();
            txtStatus.Text = "Status: Servidor parado.";
            btnStart.IsEnabled = true;
        }
    }
}